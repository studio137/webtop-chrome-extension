document.addEventListener('DOMContentLoaded', function () {

    var today = new Date();
    var time = formatTime(today.getHours()) + ":" + formatTime(today.getMinutes());
    document.getElementById('time').innerHTML = time;

    changeNewTab();

    chrome.runtime.onMessage.addListener(function(msg, _, sendResponse) {
      if (msg.action == "updateImage") {
        updateNewTab();
        sendResponse({status: "success"});
      }
    });

    
    
});


function changeNewTab() {

  var xhr = new XMLHttpRequest();
  xhr.open("GET", "https://api.webtop.cloud/v1/startertab", true);
  xhr.onreadystatechange = function() {

    if (xhr.readyState == 4) {
      
      var data = JSON.parse(xhr.responseText);
      document.getElementById('bg').style.backgroundImage = 'url(' + data.bgImage + ')';
      document.getElementById('quote').innerHTML = data.quote;
      
    }

  }
  xhr.send();

}


function updateNewTab() {

  var xhr = new XMLHttpRequest();
  xhr.open("GET", "https://api.webtop.cloud/v1/startertab/randomize", true);
  xhr.onreadystatechange = function() {

    if (xhr.readyState == 4) {
      
      var data = JSON.parse(xhr.responseText);
      document.getElementById('bg').style.backgroundImage = 'url(' + data.bgImage + ')';
      document.getElementById('quote').innerHTML = data.quote;
      
    }

  }
  xhr.send();

}


function formatTime(time) {
    if(time < 10) {
        return "0" + time;
    }
    return time;
}